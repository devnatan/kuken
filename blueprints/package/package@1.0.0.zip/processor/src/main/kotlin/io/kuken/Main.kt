package io.kuken

import org.pkl.config.java.ConfigEvaluatorBuilder
import org.pkl.config.kotlin.forKotlin
import org.pkl.config.kotlin.to
import org.pkl.core.ModuleSource

data class Birds(
    /**
     * The birds that we know about.
     */
    val birds: Map<String, Bird>
) {
    data class Bird(
        /**
         * The name of the bird
         */
        val name: String,
        /**
         * The bird's features
         */
        val features: Features
    )

    data class Features(
        /**
         * Can this bird mimick other sounds?
         */
        val voiceMimickry: Boolean,
        /**
         * Can this bird fly?
         */
        val flies: Boolean,
        /**
         * Can this bird swim?
         */
        val swims: Boolean
    )
}

fun main() {
    val evaluator = ConfigEvaluatorBuilder.preconfigured().forKotlin().build()
    val config = evaluator.evaluate(ModuleSource.modulePath("config.pkl"))

    val birds = config.to<Birds>()

    println("Birds: $birds")
}